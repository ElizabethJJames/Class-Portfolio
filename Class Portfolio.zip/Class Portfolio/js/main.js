import navigationJS from './modules/nav.js'

navigationJS();
