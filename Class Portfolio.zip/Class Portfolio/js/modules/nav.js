export default function navigationJS(){
  return alert('I am working');
}
